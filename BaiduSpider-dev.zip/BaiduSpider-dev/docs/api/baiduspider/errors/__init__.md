::: baiduspider.errors.__init__
    rendering:
      show_root_heading: true
      show_source: true