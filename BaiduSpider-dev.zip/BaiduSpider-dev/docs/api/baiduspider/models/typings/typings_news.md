::: baiduspider.models.typings.typings_news
    rendering:
      show_root_heading: true
      show_source: true