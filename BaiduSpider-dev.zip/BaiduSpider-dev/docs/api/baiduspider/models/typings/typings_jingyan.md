::: baiduspider.models.typings.typings_jingyan
    rendering:
      show_root_heading: true
      show_source: true