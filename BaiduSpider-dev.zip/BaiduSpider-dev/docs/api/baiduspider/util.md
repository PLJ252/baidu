::: baiduspider.util
    selection:
      members:
        - handle_err
    rendering:
      show_root_heading: true
      show_source: true