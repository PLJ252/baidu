black -q ./baiduspider
black -q ./setup.py
black -q ./generate_typings.py